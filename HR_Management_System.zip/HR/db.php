<?php

	function DBconnection(){
		$conn= oci_connect('Anik', 'anik', 'localhost/XE');

		return $conn;
	}


?>