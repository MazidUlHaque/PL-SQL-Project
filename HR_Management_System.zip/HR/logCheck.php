<?php
	session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST"){
		$name = trim($_POST['name']);
		$password = trim($_POST['password']);

		$isValid = "";

		if($name == "" && $password == "" ){

			header("location: login.php?status=nullvalue");
		}else
		{
			$conn = oci_connect('system', '2645', 'localhost/XE');

			if(!$conn){
				echo "DB Error: ";
			}else{
				echo "Success <br/>";
			}


	$sql= "select username,password from dba_users";

	$result = oci_parse($conn, $sql);
	$r=oci_execute($result);

	$connU = oci_connect('Anik', 'anik', 'localhost/XE');

	if(!$connU){
				echo "DB Error: ";
			}else{
				echo "Success <br/>";
			}

	$sqlu= "select LOGIN_USERNAME,USER_PASSWORD from LOGIN_INFO";

	


	$resultu = oci_parse($connU, $sqlu);
	oci_execute($resultu);



	while($row = oci_fetch_assoc($result)){
			
		if($row['USERNAME'] == strtoupper($name) && strtolower($password) =="anik"  ){
					
					$_SESSION['abc'] = "validadmin";

					$isValid = "validAdmin";

					
				}



				} 
				//echo("<pre>");print_r($GLOBALS);echo("</pre>");
	while($rowu = oci_fetch_assoc($resultu)){
			
			//echo $rowu['LOGIN_USERNAME'];echo $rowu['USER_PASSWORD'];
		if(strtolower($rowu['LOGIN_USERNAME']) == strtolower($name) && $rowu['USER_PASSWORD'] == strtolower($password) ){
					
					$_SESSION['def'] = "validuser";

					$isValid = "User";

					
				}


				} 

			if($isValid == "User"){
				header("location: user/index.php");

			}elseif ($isValid == "validAdmin"){
				header("location:index.php");
			}
			else
			{
				//echo $isValid;
				//echo $name ;
				//echo $password;
				//echo "nooooo";
				header("location: login.php?status=invaliduser");
			}
			
			
		}

	
}
else
{
	echo "invalid";
}



	
?>