                <div class="dropdown-menu" aria-labelledby="pagesDropdown">
                    <h6 class="dropdown-header">Info:</h6>
                    <a class="dropdown-item" href="index.php">Employee</a>
                    <a class="dropdown-item" href="dept.php">Department</a>
                    <a class="dropdown-item" href="salary.php"> Salary</a>
                    <a class="dropdown-item" href="training.php"> Training</a>
					
					<div class="dropdown-divider"></div>
                    <h6 class="dropdown-header">Login And Others:</h6>
					<a class="dropdown-item" href="logininfo.php">Login Info</a>
					<a class="dropdown-item" href="roles.php">Roles</a>
					<a class="dropdown-item" href="permission.php">Permissions</a>

					
					<div class="dropdown-divider"></div>
                    <h6 class="dropdown-header">Logs:</h6>
					<a class="dropdown-item" href="sallog.php">Salary Logs</a>
                    
                </div>              