                <div class="dropdown-menu" aria-labelledby="pagesDropdown">
                    <h6 class="dropdown-header">Info:</h6>
                    <a class="dropdown-item" href="index.php">Employee</a>
                    <a class="dropdown-item" href="department.php">Department</a>
                    <a class="dropdown-item" href="salary.php"> Salary</a>
                    <a class="dropdown-item" href="training.php"> Training</a>
                    <div class="dropdown-divider"></div>
                    <h6 class="dropdown-header">Others:</h6>
                    <a class="dropdown-item" href="logininfo.php">Login</a>
                    <a class="dropdown-item" href="roles.php">Roles</a>
                    <a class="dropdown-item" href="users.php">Users</a>
                    <a class="dropdown-item" href="permission.php">Permission</a>
                </div>              